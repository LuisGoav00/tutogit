<?php
    echo "Hola mundo con AJAX";
?>